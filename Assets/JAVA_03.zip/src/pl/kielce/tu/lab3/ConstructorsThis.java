package pl.kielce.tu.lab3;

class ConstructorsThis {
	int i, j;

	ConstructorsThis() {
	}

	ConstructorsThis(int i) {
		this();
		this.i = 1;
	}

	ConstructorsThis(int i, int j) {
		this(i);
		this.j = j;
	}

	public static void main(String[] args) {
		ConstructorsThis c0 = new ConstructorsThis();
		ConstructorsThis c1 = new ConstructorsThis(1);
		ConstructorsThis c2 = new ConstructorsThis(1, 2);
		System.out.println("c0.i = " + c0.i + " c0.j = " + c0.j);
		System.out.println("c1.i = " + c1.i + " c1.j = " + c1.j);
		System.out.println("c2.i = " + c2.i + " c2.j = " + c2.j);
	}
}