package pl.kielce.tu.lab3;

import java.util.Random;

public class StaticInit {
	static int n;
	static {
		Random r = new Random();
		for (int i = 0; i < 10; i++)
			n += r.nextInt();
		n /= 10;
	}
	
	public static void main(String[] args) {
		System.out.println("StaticInit.n = " + StaticInit.n);
	}
}