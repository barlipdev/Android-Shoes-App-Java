package pl.kielce.tu.lab3;

public class OuterClass2 {

	private String name = "OuterClassName";

	public void test() {
		class InnerClass {
			String name = "InnerClassName";

			void print() {
				String name = "LocalVariableName";
				System.out.println(name);
				System.out.println(this.name);
				System.out.println(OuterClass2.this.name);
			}
		}
		InnerClass i = new InnerClass();
		i.print();
	}

	public static void main(String[] args) throws Exception {
		OuterClass2 o = new OuterClass2();
		o.test();
		// InnerClass i1 = new InnerClass();   //Error
		// InnerClass i2 = o.new InnerClass(); //Error
	}
}