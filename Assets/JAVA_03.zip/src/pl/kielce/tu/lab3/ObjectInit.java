package pl.kielce.tu.lab3;

public class ObjectInit {
	int i;
	int j;
	int k;
	{
		System.out.println("Init");
		k = 3;
	}

	ObjectInit(int i) {
		System.out.println("Init i = " + i);
		this.i = i;
	}

	ObjectInit(int i, int j) {
		System.out.println("Init i = " + i + ", j = " + j);
		this.i = i;
		this.j = j;
	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		ObjectInit i1 = new ObjectInit(1);
		ObjectInit i2 = new ObjectInit(1, 2);
	}
}