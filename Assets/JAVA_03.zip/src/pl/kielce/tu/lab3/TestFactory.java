package pl.kielce.tu.lab3;

class Factory {

    int i;

	Factory(){
        this.i = 0;
	}

	Factory(int i){
        this.i = i;
	}

	static Factory getInstance(boolean condition){
        if(condition)
            return new Factory(1);
        else
            return new Factory();
	}
}

public class TestFactory {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Factory f1 = new Factory();
		Factory f2 = Factory.getInstance(true);
	}
}


