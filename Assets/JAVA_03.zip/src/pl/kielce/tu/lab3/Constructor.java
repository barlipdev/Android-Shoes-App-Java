package pl.kielce.tu.lab3;

public class Constructor {
}