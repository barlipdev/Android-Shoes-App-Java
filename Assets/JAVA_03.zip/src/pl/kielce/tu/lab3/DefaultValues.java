package pl.kielce.tu.lab3;

public class DefaultValues {
	
	boolean b;
	char c;
	byte by;
	short s;
	int i;
	long l;
	float f;
	double d;
	Object o;
	
	public static void main(String[] args) {
		DefaultValues v = new DefaultValues();
		System.out.println("boolean = " + v.b);
		System.out.println("char = " + v.c);
		System.out.println("byte = " + v.by + ", short = " + v.s + ", int = " + v.i + ", long = " + v.l);
		System.out.println("float = " + v.f + ", double = " + v.d);
		System.out.println("object = " + v.o);
	}
}
