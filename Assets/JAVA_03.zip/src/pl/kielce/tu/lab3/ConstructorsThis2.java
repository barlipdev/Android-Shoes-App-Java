package pl.kielce.tu.lab3;

class ConstructorsThis2 {
	int i, j;
	final private static int DEFAULT_I = -1;
	final private static int DEFAULT_J = -2;

	ConstructorsThis2() {
		this(DEFAULT_I, DEFAULT_J);
	}

	ConstructorsThis2(int i) {
		this(i, DEFAULT_J);
	}

	ConstructorsThis2(int i, int j) {
		this.i = i;
		this.j = j;
	}

	public static void main(String[] args) {
		ConstructorsThis2 c0 = new ConstructorsThis2();
		ConstructorsThis2 c1 = new ConstructorsThis2(1);
		ConstructorsThis2 c2 = new ConstructorsThis2(1, 2);
		System.out.println("c0.i = " + c0.i + " c0.j = " + c0.j);
		System.out.println("c1.i = " + c1.i + " c1.j = " + c1.j);
		System.out.println("c2.i = " + c2.i + " c2.j = " + c2.j);
	}
}