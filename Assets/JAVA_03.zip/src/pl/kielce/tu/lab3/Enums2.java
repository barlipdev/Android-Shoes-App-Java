package pl.kielce.tu.lab3;

enum Months {
	JANUARY("Styczeń"), FRBRUARY("Luty"), MARCH("Marzec");
	
	String pl;
	
	Months(String pl){
		this.pl = pl;
	}
	
	String engToPl(){
		return pl;
	}
};

public class Enums2 {

	public static void main(String[] args) {
		Months d = Months.JANUARY;
		System.out.println(d.ordinal() + " : " + d.name() + " : " + d.engToPl());
		d = Months.MARCH;
		System.out.println(d.ordinal() + " : " + d.name() + " : " + d.engToPl());
	}
}
