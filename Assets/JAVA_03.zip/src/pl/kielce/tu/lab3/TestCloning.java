package pl.kielce.tu.lab3;

class MyClass implements Cloneable {
	OtherObject o = new OtherObject();
	
	MyClass() {
		System.out.println("Default constructor");
	}

	public Object clone(boolean shallow) throws CloneNotSupportedException {
		MyClass clone = (MyClass)clone();
		if(shallow)
			return clone;
		clone.o = (OtherObject) o.clone();
		return clone;
	}
	
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return (MyClass)super.clone();
	}

	@Override
	public String toString() {
		return super.toString() + " -> " + o.toString();
	}
}

class OtherObject implements Cloneable {
	@Override
	protected Object clone() throws CloneNotSupportedException {
		return (OtherObject)super.clone();
	}
}

public class TestCloning {
	public static void main(String arg[]) throws CloneNotSupportedException {
		MyClass p = new MyClass();
		MyClass p2 = (MyClass) p.clone(true);
		System.out.println(p);
		System.out.println(p2);
		p2 = (MyClass) p.clone(false);
		System.out.println(p);
		System.out.println(p2);
	}
}