package pl.kielce.tu.lab3;

enum Days {
	MONDAY, TUESDAY, WEDNESDAY
};

public class Enums {

	private static String engToPl(Days d) {
		switch (d) {
			case MONDAY:
				return "Poniedziałek";
			case TUESDAY:
				return "Wtorek";
			case WEDNESDAY:
				return "Środa";
			default:
				return "";
		}
	}

	public static void main(String[] args) {
		Days d = Days.MONDAY;
		System.out.println(d.ordinal() + " : " + d.name() + " : " + engToPl(d));
		d = Days.WEDNESDAY;
		System.out.println(d.ordinal() + " : " + d.name() + " : " + engToPl(d));
	}
}
