package pl.kielce.tu.lab3;

class ConstructorsOverloading {
	int i, j;

	ConstructorsOverloading() {
	}

	ConstructorsOverloading(int i) {
		this.i = i;
	}

	ConstructorsOverloading(int i, int j) {
		this.j = j;
	}

	public static void main(String[] args) {
		ConstructorsOverloading c0 = new ConstructorsOverloading();
		ConstructorsOverloading c1 = new ConstructorsOverloading(1);
		ConstructorsOverloading c2 = new ConstructorsOverloading(1, 2);
		System.out.println("c0.i = " + c0.i + " c0.j = " + c0.j);
		System.out.println("c1.i = " + c1.i + " c1.j = " + c1.j);
		System.out.println("c2.i = " + c2.i + " c2.j = " + c2.j);
	}
}