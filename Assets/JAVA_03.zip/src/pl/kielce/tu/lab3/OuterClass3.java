package pl.kielce.tu.lab3;

public class OuterClass3 {
	
	static private String name = "OuterClassName";
	
	static class StaticClass {
		String name = "StaticClassName";
		
		void print() {
			String name = "LocalVariableName";
			System.out.println(name);
			System.out.println(this.name);
			System.out.println(OuterClass3.name);
		}
	}
	
	public static void main(String[] args) throws Exception {
		StaticClass i = new StaticClass();
		i.print();
	}
}