package pl.kielce.tu.lab3;

class OtherClass {
	OtherClass(){
		System.out.println("OtherClass");
	}
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		OtherClass b = new OtherClass();
		PublicClass a = new PublicClass();
	}
}

public class PublicClass {
	PublicClass() {
		System.out.println("PublicClass");
	}
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		PublicClass a = new PublicClass();
		OtherClass b = new OtherClass();
	}
}
