package pl.kielce.tu.lab3;

public class OuterClass1 {
	
	private String name = "OuterClassName";
	
	class InnerClass {
		String name = "InnerClassName";
		
		void print() {
			String name = "LocalVariableName";
			System.out.println(name);
			System.out.println(this.name);
			System.out.println(OuterClass1.this.name);
		}
	}
	
	public static void main(String[] args) throws Exception {
		OuterClass1 o = new OuterClass1();
		InnerClass i = o.new InnerClass();
		i.print();
	}
}