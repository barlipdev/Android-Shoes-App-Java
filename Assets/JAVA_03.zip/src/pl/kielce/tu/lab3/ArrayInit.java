package pl.kielce.tu.lab3;

class ArrayInit {

	public static void main(String[] args) {
		int[] tab1 = new int[3];
		System.out.println("tab1.length = " + tab1.length + " tab1[0] = " + tab1[0]);
		
		for (int i = 0; i < tab1.length; i++)
			tab1[i] = i + 1;
		System.out.println("tab1.length = " + tab1.length + " tab1[0] = " + tab1[0]);
		
		int[] tab2 = { 4, 5, 6 };
		System.out.println("tab2.length = " + tab2.length + " tab2[0] = " + tab2[0]);
		
		int[] tab3 = new int[] { 7, 8, 9 };
		System.out.println("tab3.length = " + tab3.length + " tab3[0] = " + tab3[0]);
	}
}
