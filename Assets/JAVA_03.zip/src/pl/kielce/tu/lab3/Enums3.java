package pl.kielce.tu.lab3;

enum ColorModel {
	RGB{
		@Override
		String getDescription() {
			return "Red Green Blue";
		}
	}, 
	CMYK{
		@Override
		String getDescription() {
			return "Cyan Magenta Yellow Black";
		}		
	};
	
	abstract String getDescription();
};

public class Enums3 {

	public static void main(String[] args) {
		for(ColorModel c: ColorModel.values())
			System.out.println(c.ordinal() + " : " + c.name() + " : " + c.getDescription());
	}
}
