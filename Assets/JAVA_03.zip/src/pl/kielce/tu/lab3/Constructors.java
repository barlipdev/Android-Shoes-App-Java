package pl.kielce.tu.lab3;

class Constructors {
	int i;
	int j;
	
	Constructors(int i) {
		this.i = 1;
	}
	
	Constructors(int i, int j) {
		this(i);
		this.j = j;
	}
	
	public static void main(String[] args) {
		Constructors c1 = new Constructors(5);
		Constructors c2 = new Constructors(10, 11);
		System.out.println("c1.i = " + c1.i + " c1.j = " + c1.j);
		System.out.println("c2.i = " + c2.i + " c2.j = " + c2.j);
	}
}