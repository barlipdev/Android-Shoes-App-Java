package pl.kielce.tu.lab3;

class Clone implements Cloneable {
	int i, j;

	Clone(int i, int j){
		this.i = i;
		this.j = j;
	}

	@Override public Clone clone() throws CloneNotSupportedException {
    	return (Clone) super.clone();
    }

	@Override public String toString(){
		return super.toString() + " " + i + " " + j;
	}
}

public class TestClone {
	public static void main(String[] args) throws Exception{
		Clone c = new Clone(1, 2);
		System.out.println(c);
		Clone c2 = c.clone();
		System.out.println(c2);
	}
}


